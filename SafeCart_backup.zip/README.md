# SafeCart backup (saved 29 Oct 2026)

This ZIP holds everything needed to run or rebuild SafeCart, whatever happens to your Quick subscription.

## Contents
- working_model/SafeCart_working_model.html   Open in any browser, works offline, no account needed
- agents/            Full setup of all 4 agents (instructions, welcome message, starter prompts, skills used)
- skills/            The 3 skills, each with its SKILL.md and Python scoring script
- rules/SafeCart_Rules.md   All keywords, weights, thresholds and compliance rules
- data/              Validation set (with answer keys), validation results, demo results, raw agent outputs
- diagrams/          Orchestration diagram (PNG + editable SVG)

## Rebuilding the agents elsewhere
- Quick (new account): create each agent and paste in its instructions from agents/. Upload the skills, and add rules/ and data/ to a space.
- n8n / Lovable / any LLM tool: the scripts in skills/*/scripts/ are plain Python. The agent instructions work as system prompts.
- ChatGPT / Claude custom GPTs or projects: paste the agent instructions and attach SafeCart_Rules.md.

## Validation results (synthetic test set)
Safety recall 100% (30/30) | Precision 100% | Harm-type accuracy 97% (29/30) | Listing violations caught 20/20
The test set was written to match the Amazon Reviews 2023 format. Re-test on hand-labelled real reviews.
