import pandas as pd

WEIGHTS = {'Baby_Products': 1.5, 'Toys': 1.5, 'Health': 1.4, 'Beauty': 1.3, 'Electronics': 1.3}
KEYWORDS = r'fire|smoke|burn|shock|spark|rash|allerg|chok|swallow|expired|leak|explod|overheat|injur|itch|hives|blister|cut|swell|scald'
HARM_TYPES = ['fire', 'electrical', 'chemical', 'allergic', 'choking', 'injury', 'expired', 'none']
HARM_MAP = {
    'fire_hazard': 'fire', 'overheating': 'fire', 'smoke': 'fire', 'explosion': 'fire', 'battery_swelling': 'fire',
    'electrical_shock': 'electrical', 'shock': 'electrical', 'spark': 'electrical', 'sparking': 'electrical',
    'chemical_burn': 'chemical', 'poisoning': 'chemical', 'toxic': 'chemical',
    'allergic_reaction': 'allergic', 'skin_reaction': 'allergic', 'rash': 'allergic', 'irritation': 'allergic',
    'ingestion': 'choking', 'swallowing': 'choking', 'choking_hazard': 'choking',
    'burn': 'injury', 'cut': 'injury', 'fall_injury': 'injury', 'entrapment': 'injury', 'eye_injury': 'injury',
    'laceration': 'injury', 'scald': 'injury',
    'expired_product': 'expired', 'expiry': 'expired',
}

def normalize_harm(df):
    raw = df['harm_type'].astype(str).str.strip().str.lower()
    df['harm_type_raw'] = raw
    def m(h):
        if h in HARM_TYPES:
            return h
        if h in HARM_MAP:
            return HARM_MAP[h]
        return 'none' if h in ('', 'nan') else 'injury'
    df['harm_type'] = raw.map(m)
    df.loc[df['safety_issue'] != True, 'harm_type'] = 'none'
    df['harm_remapped'] = df['harm_type'] != df['harm_type_raw']
    return df

def prefilter(df):
    m = (df['rating'] <= 3) | df['text'].astype(str).str.lower().str.contains(KEYWORDS)
    return df[m].copy()

def score(df):
    df = normalize_harm(df)
    def risk(r):
        if not r['safety_issue']:
            return 0
        return round(r['severity'] * WEIGHTS.get(r.get('category'), 1.0) * r['confidence'] * 20)
    df['risk_score'] = df.apply(risk, axis=1)
    df['tier'] = df['risk_score'].apply(lambda x: 'CRITICAL' if x >= 80 else 'HIGH' if x >= 40 else 'LOW' if x > 0 else 'NONE')
    counts = df[df['safety_issue'] == True].groupby('asin').size()
    df['asin_flag_count'] = df['asin'].map(counts).fillna(0).astype(int)
    df['boosted'] = (df['asin_flag_count'] >= 3) & (df['tier'] != 'CRITICAL') & (df['safety_issue'] == True)
    df.loc[df['boosted'], 'tier'] = 'CRITICAL'
    df['action'] = df['tier'].map({'CRITICAL': 'Suppress listing pending investigation', 'HIGH': 'Investigate within 48h'}).fillna('')
    return df

def save(df, path):
    with pd.ExcelWriter(path) as x:
        df[df.tier.isin(['CRITICAL', 'HIGH'])].to_excel(x, sheet_name='escalations', index=False)
        df[~df.tier.isin(['CRITICAL', 'HIGH'])].to_excel(x, sheet_name='results', index=False)
