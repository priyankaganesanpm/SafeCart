---
name: safecart-review-scoring
display_name: SafeCart Review Scoring
description: "Use whenever product reviews (CSV/Excel, e.g. Amazon Reviews 2023) need scanning for safety signals: pre-filter, classify harm, risk-score, tier CRITICAL/HIGH/LOW/NONE, apply the 3-flag ASIN boost and produce escalations."
icon: "🚨"
trigger: scan reviews for safety issues
inputs:
  - name: reviews_file
    description: "Reviews file with review_id, asin, rating, title, text, date (category optional)"
    type: path
    required: true
tools: [run_python, open_in_session_tab, file_write]
scripts: [score_reviews.py]
id: 92116d406dbd4df494f84ab095d17117
---

## Overview
Turns a raw reviews file into tiered safety escalations. Code does the filtering, scoring, label clean-up and boosting so results are deterministic; the model only classifies review text.

## Workflow

### Step 1: Load and pre-filter
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: {{reviews_file}}
- **Output**: Filtered reviews (rating <= 3 OR safety keyword match)
- **Validate**: Required columns present; report kept vs dropped counts
- **On failure**: If columns are missing, map them sensibly and tell the user, or stop and ask
Keywords: fire|smoke|burn|shock|spark|rash|allerg|chok|swallow|expired|leak|explod|overheat|injur|itch|hives|blister|cut|swell|scald. The keyword rule exists because people report harm in 4-5 star reviews.

### Step 2: Sample-first
- **Mode**: `agentic`
- **Input**: Filtered reviews
- **Output**: First 200 classified, plus a confirmation question
- **Validate**: User confirms before the remainder is processed
- **On failure**: If the user declines, deliver the sample results only

### Step 3: Classify
- **Mode**: `agentic`
- **Input**: Each filtered review
- **Output**: safety_issue, harm_type, severity, affected_user, evidence, confidence
- **Validate**: Evidence is an exact quote; harm_type is one of the 8 allowed labels
- **On failure**: Mark unparseable rows safety_issue=false, confidence=0 and list them
Rules:
- safety_issue only for physical harm or health risk, not poor quality.
- harm_type must be exactly one of: fire, electrical, chemical, allergic, choking, injury, expired, none. Don't create sub-labels. Burns, cuts, falls, scalds, entrapment and eye injuries are "injury". Rashes, hives and skin reactions are "allergic". Shocks and sparks are "electrical". Overheating, smoke and battery swelling are "fire". Poisoning and chemical burns are "chemical". Swallowed small parts are "choking". A fixed label set keeps the digest's harm-type counts meaningful.
- Severity 5 injury/risk to life, 4 likely harm, 3 potential hazard, 2 quality, 1 none. A child involved means +1 severity (max 5).
- Never invent details. When unsure, flag with lower confidence; missing harm costs more than a false alarm.

### Step 4: Score, tier, boost
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: Classified rows
- **Output**: harm_type (normalised), harm_type_raw, harm_remapped, risk_score, tier, asin_flag_count, boosted, action
- **Validate**: Tier counts add up to the filtered total; every harm_type is in the allowed list
- **On failure**: Re-run with defensive defaults
Use scripts/score_reviews.py score(). It remaps any off-list harm label back onto the 8 allowed labels and keeps the original in harm_type_raw. Report how many labels were remapped.

### Step 5: Deliver
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: Scored rows
- **Output**: Excel with escalations (CRITICAL, HIGH) and results (LOW, NONE) tabs
- **Validate**: The file opens
- **On failure**: Fall back to CSV

## Output
An Excel workbook plus a chat summary: tier counts, top risky ASINs with evidence quotes, harm-type counts and the recommended actions.

## Lessons Learned
### Do
- Keep the keyword rule; 4-5 star safety reviews are real
- Show which reviews were boosted by the ASIN pattern rule
### Don't
- Don't count quality complaints ("broke", "faded") as safety
- Don't flag keyword traps like "this deal is fire"
- Don't invent harm sub-labels; validation found 17 labels where 8 were allowed
### Common Failures
- pandas to_excel needs sheet_name= as a keyword
### When to Ask the User
- Before a full run on more than 200 filtered reviews
- When category is missing (needed for weights)
