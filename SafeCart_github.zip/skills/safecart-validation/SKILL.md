---
name: safecart-validation
display_name: SafeCart Recall/Precision Calculator
description: "Use whenever SafeCart (or any safety classifier) output must be compared with hand labels: calculates recall, precision and a confusion breakdown, lists misses and false alarms, and checks that planted listing violations were caught."
icon: "🎯"
trigger: validate safecart results
inputs:
  - name: predictions_file
    description: "Agent output with review_id and safety_issue (or asin and reasons for listings)"
    type: path
    required: true
  - name: answer_key_file
    description: "Hand labels with review_id and true_safety (or asin and planted)"
    type: path
    required: true
tools: [run_python, open_in_session_tab, file_write]
scripts: [metrics.py]
id: 026ad7be731c4e9dbbf41d6714d306b2
---

## Overview
Measures how well SafeCart performs against ground truth. Recall comes first (target 90% or more) because a missed safety issue costs far more than a false alarm. The precision target is 70% or more.

## Workflow

### Step 1: Join
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: {{predictions_file}}, {{answer_key_file}}
- **Output**: A joined table
- **Validate**: Every answer-key row is matched. Reviews dropped by the pre-filter count as predicted false.
- **On failure**: Report unmatched IDs

### Step 2: Metrics
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: Joined table
- **Output**: TP, FP, FN, TN, recall, precision
- **Validate**: TP + FN equals the number of real safety issues
- **On failure**: Check boolean parsing
Use scripts/metrics.py.

### Step 3: Diagnose
- **Mode**: `agentic`
- **Input**: Misses and false alarms
- **Output**: Explanations and fixes with the trade-off stated
- **Validate**: Each miss is attributed to the pre-filter or to classification
- **On failure**: List the rows without a diagnosis
If recall is under 90%, suggest widening keywords or lowering the CRITICAL threshold, and state the precision and cost trade-off.

### Step 4: Listings check
- **Mode**: `agentic`
- **Input**: Listing reasons vs planted violations
- **Output**: Caught X/20, with misses listed
- **Validate**: Planted counts match the answer key
- **On failure**: Show the comparison per ASIN

## Output
A filled scorecard (recall, precision, listings checked, violations caught, pass rate) plus a short list of misses with fixes.

## Lessons Learned
### Do
- Count pre-filter drops as false negatives; they are real misses
### Don't
- Don't report precision alone
### Common Failures
- "True"/"False" strings vs booleans; normalise them
### When to Ask the User
- When the answer key and predictions use different IDs
