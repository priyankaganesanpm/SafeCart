import pandas as pd

def _b(v):
    return str(v).strip().lower() in ('true', '1', 'yes')

def metrics(pred, key, id_col='review_id', pred_col='safety_issue', true_col='true_safety'):
    df = key[[id_col, true_col]].merge(pred[[id_col, pred_col]], on=id_col, how='left')
    df[pred_col] = df[pred_col].fillna(False).map(_b)
    df[true_col] = df[true_col].map(_b)
    tp = int((df[pred_col] & df[true_col]).sum())
    fp = int((df[pred_col] & ~df[true_col]).sum())
    fn = int((~df[pred_col] & df[true_col]).sum())
    tn = int((~df[pred_col] & ~df[true_col]).sum())
    recall = tp / (tp + fn) if tp + fn else 0
    precision = tp / (tp + fp) if tp + fp else 0
    return dict(tp=tp, fp=fp, fn=fn, tn=tn, recall=round(recall * 100, 1), precision=round(precision * 100, 1),
                misses=df[~df[pred_col] & df[true_col]][id_col].tolist(),
                false_alarms=df[df[pred_col] & ~df[true_col]][id_col].tolist())
