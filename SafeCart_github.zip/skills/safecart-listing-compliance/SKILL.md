---
name: safecart-listing-compliance
display_name: SafeCart Listing Compliance Check
description: "Use whenever marketplace listings need checking against Indian rules: Legal Metrology mandatory fields, BIS/FSSAI numbers, and restricted claims (medical, absolute safety, unverifiable certification, superlatives). Produces a score and PASS / FIX REQUIRED / BLOCK."
icon: "📋"
trigger: check listings for compliance
inputs:
  - name: listings_file
    description: "Listings file with asin, title, category, description, mrp, net_qty, manufacturer, country_of_origin, customer_care, bis_no, fssai_no"
    type: path
    required: true
tools: [run_python, open_in_session_tab, file_write]
scripts: [compliance.py]
id: 67d153fa6ff640bf9d1ef0ce5516531c
---

## Overview
Rule checks run in code (cheap, repeatable, auditable). Restricted-claim spotting is the only judgment step. Every listing gets a score, a status and the reasons.

## Workflow

### Step 1: Rule checks
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: {{listings_file}}
- **Output**: rule_fails and hard_block per listing
- **Validate**: Every listing has a rule_fails list (it may be empty)
- **On failure**: Report missing columns
Use scripts/compliance.py rule_checks, which returns (fails, hard_block). A missing BIS or FSSAI number sets hard_block. Remind the user to verify the current BIS compulsory list.

### Step 2: Restricted claims
- **Mode**: `agentic`
- **Input**: Title and description of each listing
- **Output**: violations [{claim (exact quote), type, suggested_fix}]
- **Validate**: Each claim is quoted verbatim
- **On failure**: Leave the list empty and note the row
Types: medical (cures/treats/heals/clinically proven to treat), safety (100% safe, no side effects), certification (FDA approved, ISI certified without a number), superlative (No.1, best in India, "best" without evidence). Suggested fixes must be compliant, factual rewrites.

### Step 3: Score and deliver
- **Mode**: `deterministic`
- **Tool**: `run_python`
- **Input**: rule_fails, hard_block and violations
- **Output**: compliance_score, status, reasons, saved to Excel
- **Validate**: Scores are within 0-100, and no listing with any issue has status PASS
- **On failure**: Fall back to CSV
Score = max(0, 100 - 15 x fails - 20 x violations). Status rules, in order:
1. A missing BIS or FSSAI number is an automatic BLOCK, whatever the score. Uncertified regulated products must not be sold.
2. Score under 60 is BLOCK.
3. Any rule failure or claim means the listing cannot PASS; it is FIX REQUIRED.
4. PASS only when there are zero issues.
Use scripts/compliance.py score(fails, violations, hard_block).

## Output
A listing_compliance table plus a chat summary: pass rate, BLOCK list and most common issues.

## Lessons Learned
### Do
- Treat blank strings as missing
- Count each claim separately, even when two are in one sentence
### Don't
- Don't use the model for the mandatory-field checks
- Don't let a single missing field slip through as PASS; validation showed the plain score threshold allowed that
### Common Failures
- NaN from Excel looks non-empty; normalise to ''
### When to Ask the User
- When a category isn't in the known lists and might need BIS or FSSAI
