import pandas as pd

LM = ['mrp', 'net_qty', 'manufacturer', 'country_of_origin', 'customer_care']
BIS_CATS = ['Electronics', 'Toys', 'Cell_Phones']
FOOD_CATS = ['Grocery', 'Health']

def _blank(v):
    return v is None or (isinstance(v, float) and pd.isna(v)) or str(v).strip() == ''

def rule_checks(row):
    """Returns (fails, hard_block). A missing BIS or FSSAI number is a hard block."""
    fails = [f'LegalMetrology: missing {f}' for f in LM if _blank(row.get(f))]
    hard = False
    if row.get('category') in BIS_CATS and _blank(row.get('bis_no')):
        fails.append('BIS: registration number missing (auto-BLOCK)')
        hard = True
    if row.get('category') in FOOD_CATS and _blank(row.get('fssai_no')):
        fails.append('FSSAI: licence number missing (auto-BLOCK)')
        hard = True
    return fails, hard

def score(fails, violations, hard_block=False):
    s = max(0, 100 - 15 * len(fails) - 20 * len(violations))
    if hard_block or s < 60:
        status = 'BLOCK'
    elif fails or violations:
        status = 'FIX REQUIRED'
    else:
        status = 'PASS'
    reasons = ' | '.join(fails + [f"{v['type']}: \"{v['claim']}\" -> {v['suggested_fix']}" for v in violations])
    return s, status, reasons
