# SafeCart live dashboard: Lovable + Google Sheets

## Step 1: Set up the Google Sheet (about 10 min)
1. Upload `SafeCart_Google_Sheet.xlsx` to Google Drive. Open it, then choose **File → Save as Google Sheets**.
2. Keep the tab names (`escalations`, `listings`, `scorecard`, `runs`) and the column headers exactly as they are.
3. Choose **File → Share → Publish to web**. For each of the 4 tabs, select the tab, choose **Comma-separated values (.csv)**, click **Publish** and copy the link.
4. Each link looks like `https://docs.google.com/spreadsheets/d/e/.../pub?gid=...&single=true&output=csv`.

> ⚠️ "Publish to web" makes those tabs readable by anyone who has the link. That's fine for your synthetic demo data, but never publish real customer data this way. For private data, use the secure option at the bottom of this file.

## Step 2: Paste this prompt into Lovable
Replace the 4 `PASTE_…` placeholders with your links first.

---

Build a **live** single-page dashboard called **SafeCart: Product Safety & Listing Compliance**. It reads its data from a published Google Sheet. Don't use any hardcoded data.

**Data sources (CSV, fetched in the browser):**
- escalations: `PASTE_ESCALATIONS_CSV_URL`
  Columns: review_id, asin, rating, category, title, text, harm_type, severity, affected_user, evidence, confidence, risk_score, tier, asin_flag_count, boosted, action
- listings: `PASTE_LISTINGS_CSV_URL`
  Columns: asin, title, category, compliance_score, status, reasons
- scorecard: `PASTE_SCORECARD_CSV_URL`
  Columns: metric, target, result
- runs: `PASTE_RUNS_CSV_URL`
  Columns: run_date, reviews_scanned, reviews_kept, critical, high, listings_checked, pass, fix_required, block, recall_pct, precision_pct, note

**Data loading:**
- Parse the CSVs with PapaParse (header: true, dynamicTyping: true). Fetch all 4 with React Query.
- Refresh automatically every 5 minutes, and add a **Refresh** button in the header.
- Show "Last updated: <time>" and a green pulsing "Live" dot. If a fetch fails, show a red "Offline: showing last loaded data" badge and keep the previous data.
- Show skeleton loaders while the data loads, and a friendly empty state if a tab has no rows.
- Never fail if a cell is blank or a column is missing.

**Calculate everything from the data (no fixed numbers):**
- **KPI cards** (animate the numbers counting up):
  - Safety recall and precision, from the scorecard rows. Show a green tick when the target is met.
  - CRITICAL count and HIGH count, from escalations.
  - Compliance pass rate: PASS ÷ total listings.
  - BLOCK count.
- **Tier donut** (CRITICAL red, HIGH amber).
- **Harm-type bar chart:** a count per harm_type.
- **Listing status donut** (PASS green, FIX REQUIRED amber, BLOCK red).
- **Risk vs severity scatter:** one dot per escalation, coloured by category, with dashed lines at 80 (CRITICAL) and 40 (HIGH).
- **Top risky ASINs:** group escalations by asin and count them. Use a purple badge when the count is 3 or more ("3-flag boost").
- **Trend line chart from `runs`:** CRITICAL, HIGH and pass % over run_date. If there's only one run, show the message "Add a row to the runs tab after each weekly run to see trends".

**Interactions:**
- Clicking a chart slice or bar filters the matching table. Show a removable filter chip for it.
- **Escalations table:** filters for tier, harm type and category, a search box, sortable columns, and the evidence shown in italic quotes. Clicking a row opens a side drawer with the full review text, severity (note "+1 child" when affected_user = child), affected user, confidence, flags on that ASIN and the recommended action. If rating ≥ 4, show the note "A rating-only filter would have missed this."
- **Listings table:** a status filter, search, the score shown as a coloured progress bar, and `reasons` split on " | " with one reason per line.
- **Scorecard table.**
- **Animated pipeline strip:** Input → Coordinator → Pre-filter → Review Safety → Compliance → Digest & Validation → Workbook. Each step lights up in turn when the page loads and on every refresh.

**Style:** React, Tailwind, shadcn/ui and Recharts. Clean light theme with a dark-mode toggle, rounded cards, soft shadows and subtle fade-in animations. Respect `prefers-reduced-motion`. Make it responsive (KPIs in 6 columns on desktop and 2 on mobile).

**Footer:** "Risk = severity × category weight × confidence × 20 · CRITICAL ≥ 80 · HIGH ≥ 40 · Listing score = 100 − 15/rule fail − 20/claim · a missing BIS/FSSAI number is an automatic BLOCK".

---

## Step 3: Test that it updates live
1. In your Google Sheet, change one listing's status from PASS to BLOCK.
2. Wait 1–5 minutes, because Google's published CSVs are cached, then click **Refresh** in the dashboard. The pass rate and charts should update.
3. Publish the Lovable app and use its public URL in your portfolio and on LinkedIn.

## Weekly workflow
1. Run SafeCart on the week's reviews and listings.
2. Paste the agent's escalations and listing_compliance outputs into the sheet tabs.
3. Add one row to `runs`.
4. The dashboard picks up the changes on its next refresh.

## Optional follow-up prompts for Lovable
- **Private data (secure option):** "Replace the public CSV links with a Supabase Edge Function that reads the sheet through the Google Sheets API, using a service-account key stored as a Supabase secret. Share the sheet only with the service-account email."
- **Write-back:** "Add a 'Mark reviewed' button on each escalation that writes reviewed_by and reviewed_at back to the sheet through the Edge Function."
- **Alerts:** "When a refresh finds a CRITICAL escalation that wasn't there before, show a toast notification."

Lovable's integrations change often, so check its current docs for Supabase secrets and Google Sheets support before using the follow-ups.
