# Lovable prompt: SafeCart dashboard

Upload `safecart_dashboard_data.json` to Lovable first (or paste it into the chat), then paste the prompt below.

---

Build a single-page dashboard called **SafeCart: Product Safety & Listing Compliance**. It's a portfolio demo for an AI agent system that scans marketplace reviews for safety risks and checks listings against Indian compliance rules.

**Data:** use the attached `safecart_dashboard_data.json` as a static data file (`src/data/safecart.json`). Don't build a backend or authentication. Every number on the page must come from this file. Don't make up values.

**Layout (top to bottom):**

1. **Header:** title, the subtitle "AI agents for product safety and Indian listing compliance", and a small grey note showing `meta.dataset_note`.

2. **KPI cards (6 in a row, 3 per row on mobile):** Safety recall (`kpis.safety_recall_pct`%), Safety precision (`kpis.safety_precision_pct`%), Harm-type accuracy (`kpis.harm_type_accuracy_pct`%), Planted violations caught (`kpis.planted_violations_caught`), CRITICAL escalations (`kpis.critical_count`), Compliance pass rate (`kpis.compliance_pass_rate_pct`%). Show the targets under recall (≥90%) and precision (≥70%), with a green tick when the target is met.

3. **Charts row (use Recharts):**
   - A donut of `tier_counts`. CRITICAL red, HIGH amber, LOW blue, NONE grey.
   - A horizontal bar chart of `harm_type_counts`, sorted descending.
   - A donut of `listing_status_counts`. PASS green, FIX REQUIRED amber, BLOCK red.

4. **Top risky products:** a table from `top_asins` (ASIN, flags, max risk, harm types). Highlight rows where flags ≥ 3 with a "3-flag boost" badge.

5. **Escalations table:** from `escalations`. Columns: tier badge, ASIN, rating stars, category, harm type, severity, risk score, evidence quote (italic), action. Add filters for tier, harm type and category, plus a text search. Clicking a row opens a side drawer with the full review text, affected user, confidence, and whether the review was boosted.

6. **Listing compliance table:** from `listings`. Columns: ASIN, title, category, score (shown as a progress bar), status badge, reasons. Split `reasons` on " | " and show each reason as its own line. Add a status filter.

7. **Validation scorecard:** a simple table from `scorecard` (metric, target, result).

8. **Footer:** "Risk = severity × category weight × confidence × 20 · CRITICAL ≥ 80 · HIGH ≥ 40 · Listing score = 100 − 15 per rule fail − 20 per claim · a missing BIS/FSSAI number is an automatic BLOCK".

**Style:** clean and professional, light theme, Tailwind and shadcn/ui. Use status colours only for statuses. Make it responsive, with rounded cards and soft shadows.

---

## Optional follow-up prompts (paste one at a time)

- **CSV upload:** "Add an 'Upload results' button that accepts escalations.csv and listings.csv in the same columns as the JSON, and refreshes the dashboard with the uploaded data."
- **Live scoring (needs Supabase and an OpenAI or Gemini key stored as a secret, never in the frontend):** "Add a 'Test a review' panel. Send the review text, rating and category to a Supabase Edge Function that calls the LLM with this system prompt: [paste the Review Safety Specialist instructions from agents/2_SafeCart_Review_Safety_Specialist.md]. The function should return JSON (safety_issue, harm_type, severity, affected_user, evidence, confidence). Then compute risk = severity × weight × confidence × 20 in the frontend, with weights Baby_Products 1.5, Toys 1.5, Health 1.4, Beauty 1.3, Electronics 1.3, other 1.0, and show the tier."
- **Google Sheets (production version):** "Read escalations and listings from a Google Sheet called SafeCart (tabs: escalations, results, listings) through a Supabase Edge Function, instead of the static JSON."

Check Lovable's current docs for Supabase secrets and Google Sheets support before using the last two.
