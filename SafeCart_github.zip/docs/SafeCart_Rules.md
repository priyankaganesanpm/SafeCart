# SafeCart Rules Reference

## 1. Review safety pre-filter
Keep a review if rating <= 3 OR text (lowercase) matches:
fire|smoke|burn|shock|spark|rash|allerg|chok|swallow|expired|leak|explod|overheat|injur|itch|hives|blister|cut|swell|scald

## 2. Review classification
- safety_issue: true only for physical harm or health risk, not poor quality
- harm_type: exactly one of fire | electrical | chemical | allergic | choking | injury | expired | none (no sub-labels; burns/cuts/falls/scalds = injury, skin reactions = allergic, shocks/sparks = electrical, overheating/smoke = fire). Off-list labels are remapped in code.
- severity 1-5: 5 injury/risk to life, 4 likely harm, 3 potential hazard, 2 quality issue, 1 none
- If a child is involved, severity +1 (max 5)
- affected_user: child | adult | pet | unknown
- evidence: exact short quote from the review; never invent details
- confidence: 0.0-1.0

## 3. Risk score and tiers
Category weights: Baby_Products 1.5, Toys 1.5, Health 1.4, Beauty 1.3, Electronics 1.3, other 1.0
risk = severity x weight x confidence x 20 (0 if no safety issue)
Tiers: >=80 CRITICAL, 40-79 HIGH, >0 LOW, 0 NONE
Frequency boost: ASIN with >=3 safety flags -> all its flagged reviews CRITICAL
Actions: CRITICAL "Suppress listing pending investigation"; HIGH "Investigate within 48h"

## 4. Listing compliance rules
Legal Metrology mandatory: mrp, net_qty, manufacturer, country_of_origin, customer_care
BIS registration required: Electronics, Toys, Cell_Phones (verify current compulsory list)
FSSAI licence required: Grocery, Health
Restricted claims: medical (cures/treats/heals), absolute safety (100% safe, no side effects), unverifiable certification (FDA approved, ISI certified without number), unsupported superlatives (No.1, best in India)
Score = max(0, 100 - 15 x rule fails - 20 x claim violations)
Status: missing BIS or FSSAI number = automatic BLOCK; score <60 = BLOCK; any rule failure or claim = FIX REQUIRED (cannot PASS); PASS only with zero issues

## 5. Validation targets
Recall = true positives / all real safety issues (target >= 90%)
Precision = true positives / all flagged (target >= 70%)
Listings: all 20 planted violations must be caught

## 6. Data notes
Reviews: Amazon Reviews 2023 (McAuley Lab). Indian fields (MRP, BIS, FSSAI) partly hand-filled; blanks are intentional test cases. Validation set is synthetic, written to match the dataset format.
